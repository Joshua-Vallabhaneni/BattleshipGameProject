import kareltherobot.*;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.Color;
import java.lang.Math;
//Battleship class is the mother class that incorporates and uses code from the other classes.
public class Battleship extends Robot implements Runnable
{

    /**
    *Battleship constructor has standard karel parameters and super
    *Constructor invokes thread
    */
    public Battleship(int s, int a , Direction d, int b)
    {
        super(s,a,d,b);
        World.setupThread(this);
    }

    /**
    * Code is required to have a run() method as Runnable interface is implemented
    */
    public void run()
    {
    }

    public static void main(String[] args) 
    {  
        Player karel = new Player(5,5,East,100);
        Ship carl = new Ship(11,11,East,10);
        carl.setVisible(false);
        World.setVisible(true);
        World.setDelay(0);
        World.setBeeperColor(Color.red); 
        World.setWorldColor(Color.blue);
        World.setStreetColor(Color.black);
        World.setSize(10,10);
        World.showSpeedControl(true);   
        World.placeEWWall(9,1,9);
        World.placeNSWall(1,9,9);

        //karel.playBattleship allows the karel object in this class to access and use code from the player class such as using the arrow keys to move the ship
        karel.playBattleship();
        //carl.shipMaker imports all of the robots(ships) we created to this world
        carl.shipMaker();

    }

}
