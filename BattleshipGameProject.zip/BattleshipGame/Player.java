//import statements
import kareltherobot.*;
import java.awt.event.*;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.Color;
import java.lang.Math;
import java.awt.Canvas;
import java.io.File;
import java.io.IOException;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.SourceDataLine;

//player class contains code to allow the user to control the robot and "shoot" ships
public class Player extends Robot implements Runnable, KeyListener, Directions
{
    /**
    *Player constructor has standard karel parameters and super
    *Constructor invokes thread
    */
    public Player(int s, int a , Direction d, int b)
    {
        super(s,a,d,b);
        World.worldCanvas().addKeyListener(this);
        World.setupThread(this);
    }
    
    EasySound connect = new EasySound("connect.wav");
    EasySound noConnect = new EasySound("noConnect.wav");
    EasySound winGame = new EasySound("winGame.wav");
    EasySound loseGame = new EasySound("loseGame.wav");
    EasySound hitBefore = new EasySound("hitBefore.wav");
    


    /**
    *allows the robot to turn right by turning left three times
    */
    public void turnRight()
    {
        turnLeft();
        turnLeft();
        turnLeft();
    }

    /**
    *allows the robot to make a 180 and face opposite direction
    */
    public void rotateAround()
    {
        turnLeft();
        turnLeft();
    }    

    /**
    *makes robot face east by turning left until it faces east
    */
    public void faceEast()
    {
        while (!facingEast())
        {
            turnLeft();
        }
    }

    /**
    *makes robot face west by turning left until it faces west
    */
    public void faceWest()
    {
        while (!facingWest())
        {
            turnLeft();
        }
    }

    /**
    *makes robot face north by turning left until it faces north
    */
    public void faceNorth()
    {
        while (!facingNorth())
        {
            turnLeft();
        }
    }

    /**
    *makes robot face south by turning left until it faces south
    */
    public void faceSouth()
    {
        while (!facingSouth())
        {
            turnLeft();
        }
    }

    //initializing three variables. They represent attempts left, ship sections sunk, and ship sections remaining
    int attemptsLeft = 60;
    int shipSectionsSunk = 0; 
    int shipSectionsRemaining = 18;
    
    /**
    * the keyPressed method allows the arrow keys to move the robot NESW
    * also alerts the user if the main karel robot hits a wall
    * also prints out and keeps track of the score(ship sections sunk), attempts left, and the number of ship sections remaining
    * also prints out if the user lost or won the game and scenario if user hits same spot twice
    */
        public void keyPressed (KeyEvent e)
        {
            if(e.getKeyCode() == KeyEvent.VK_UP)
            {
                faceNorth();
                if (frontIsClear())
                {
                    move();
                }
                else 
                {
                    System.out.println("Out of bounds! Try another direction");
                }
            }

            if(e.getKeyCode() == KeyEvent.VK_DOWN)
            {
            faceSouth();
            if(frontIsClear())
            {
                move();
            }
            else 
            {
                System.out.println("Out of bounds! Try another direction");
            }
            }

            if (e.getKeyCode() == KeyEvent.VK_RIGHT)
            {
            faceEast();
            if (frontIsClear())
            {
                move();
            }
            else 
            {
                System.out.println("Out of bounds! Try another direction");
            }
            }   

            if (e.getKeyCode() == KeyEvent.VK_LEFT)
            {
            faceWest();
            if (frontIsClear())
            {
                move();
            }
            else 
            {
                System.out.println("Out of bounds! Try another direction");
            }
            }

            if (e.getKeyCode() == KeyEvent.VK_SPACE)
            {
                //scenario in which the user successfully hits a ship section
                if(!nextToABeeper() && nextToARobot())
                {
                    putBeeper();
                    System.out.println("HIT!");
                    attemptsLeft--;
                    System.out.println("You have " + attemptsLeft + " attemps left.");
                    shipSectionsSunk++;
                    shipSectionsRemaining--;
                    System.out.println("You have sunk " + shipSectionsSunk + " ship sections and there are " + shipSectionsRemaining + " ship sections left.");     
                    System.out.println("\n");
                    connect.threadPlay(connect);
                    
                    //scenario in which the user has hit all of the ship sections
                    if (shipSectionsRemaining == 0)
                    {
                        turnOff(); 
                        System.out.println("Great job you have won!");
                        System.out.println("\n");
                        World.reset();
                        World.readWorld("youwin.kwld");
                        World.setSize(20,20);
                        World.setBeeperColor(Color.cyan);
                        World.setNeutroniumColor(Color.cyan);
                        World.setStreetColor(Color.black);
                        World.setWorldColor(Color.black);
                        winGame.threadPlay(winGame); 
                    }
                    
                }
                //scenario in which the user tries to hit a spot which they already successfully hit before
                else if (nextToABeeper()) 
                {
                    System.out.println("Try again, you have already hit this spot");
                    System.out.println("\n");    
                    hitBefore.threadPlay(hitBefore); 
                }
                //scenario in which the user does not hit a ship section
                else if (!nextToABeeper() && !nextToARobot())
                {
                    System.out.println("MISS!");
                    attemptsLeft--;
                    System.out.println("You have " + attemptsLeft + " attemps left.");
                    System.out.println("You have sunk " + shipSectionsSunk + " ship sections and there are " + shipSectionsRemaining + " ship sections left."); 
                    System.out.println("\n");    
                    noConnect.threadPlay(noConnect);
                }
                //scenario in which the user runs out of attempts and loses the game
                if (attemptsLeft == 0)
                {
                    System.out.println("You lost the game");
                    turnOff();
                    System.out.println("\n"); 
                    loseGame.threadPlay(loseGame); 
                }
            }
        }   
     
        /**
        *keyReleased method is necessary for the KeyListener interface
        *keyReleased is not used in this program
        */
        public void keyReleased (KeyEvent e)
        {
        }
        /**
        *keyTyped method is necessary for the KeyListener interface
        *keyTyped is not used in this program
        */
        public void keyTyped (KeyEvent e)
        {
        }
        
        public void run()
        {  
            playBattleship();
        }

    /**
    *method adds background music to the game and allows the player class's code and methods to be used in the battleship main
    */  
        public void playBattleship()
        {
        }
        
    //no main here. Methods from this class are called in Battleship.java and object in the player class is made there as well
}