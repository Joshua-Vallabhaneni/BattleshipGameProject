//import statements
import kareltherobot.*;
import java.awt.Color;

//ship class adds all of the robots that form ships to the world
public class Ship extends Robot
{
    public Ship(int s, int a, Direction d, int b)
    {
        super(s,a,d,b);
    }

    /**
    *this method creates the objects(robots) which represent our boats and sets their visibility to false so that the player cannot see where the ships are until after they successfully hit it
    *we created objects in this method instead of the main because we wanted the battleship class main to call on this method rather than create the ships directly in the batleship main
    */
    public void shipMaker()
    {
        Ship twoytwox = new Ship(2,2, East, 100);
        Ship twoythreex = new Ship(2,3, East,100);
        Ship nineythreex = new Ship(9,3, East,100);
        Ship eightythreex = new Ship(8,3, East,100);
        Ship sevenythreex = new Ship(7,3, East,100);
        Ship sixythreex = new Ship(6,3, East,100);
        Ship nineyfivex = new Ship(9,5, East,100);
        Ship nineysixx = new Ship(9,6, East,100);
        Ship nineysevenx = new Ship(9,7, East,100);
        Ship nineyeightx = new Ship(9,8, East,100);
        Ship nineyninex = new Ship(9,9, East,100);
        Ship fiveyeightx = new Ship(5,8, East,100);
        Ship fouryeightx = new Ship(4,8, East,100);
        Ship threeyeightx = new Ship(3,8, East,100);
        Ship oneysixx = new Ship(1,6, East,100);
        Ship oneysevenx = new Ship(1,7, East,100);
        Ship oneyeightx = new Ship(1,8, East,100);
        Ship oneyninex = new Ship(1,9, East,100);
        
        twoytwox.setVisible(false);
        twoythreex.setVisible(false);
        nineythreex.setVisible(false);
        eightythreex.setVisible(false);
        sevenythreex.setVisible(false);
        sixythreex.setVisible(false);
        nineyfivex.setVisible(false);
        nineysixx.setVisible(false);
        nineysevenx.setVisible(false);
        nineyeightx.setVisible(false);
        nineyninex.setVisible(false);
        fiveyeightx.setVisible(false);
        fouryeightx.setVisible(false);
        threeyeightx.setVisible(false);
        oneysixx.setVisible(false);
        oneysevenx.setVisible(false);
        oneyeightx.setVisible(false);
        oneyninex.setVisible(false);
    }
}